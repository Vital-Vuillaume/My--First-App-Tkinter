#!/bin/bash
cd /home/$USER/.local/share/applications/.Color-Invertor/
python3 app.py