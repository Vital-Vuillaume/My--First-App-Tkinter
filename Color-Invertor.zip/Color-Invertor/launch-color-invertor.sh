#!/bin/bash

echo "
[Desktop Entry]
Name=Color-Invertor
Exec=/home/$USER/.local/share/applications/.Color-Invertor/color.invertor.sh
Icon=/home/$USER/.local/share/applications/.Color-Invertor/icone.ico
Terminal=false
Categories=System;
Type=Application
" > color-invertor.desktop

mv .Color-Invertor /home/$USER/.local/share/applications/
 
cp color-invertor.desktop /home/$USER/.local/share/applications/


desktop="/home/$USER/Desktop"

if [ ! -d "$desktop" ]; then
    desktop="/home/$USER/Bureau"
fi

mv color-invertor.desktop $desktop
notify-send -i "/home/$USER/.local/share/applications/.Color-Invertor/icone.ico" "Well done" "Right-click on the desktop icon and select 'Make Executable.'"